#!/bin/bash
# Запуск Джарвиса на macOS / Linux
cd "$(dirname "$0")"
PORT=8777
echo ""
echo "  J.A.R.V.I.S. запускается на http://localhost:$PORT"
echo "  Не закрывайте это окно, пока пользуетесь Джарвисом."
echo ""

open_browser() {
  sleep 1
  if command -v open >/dev/null; then open -a "Google Chrome" "http://localhost:$PORT" 2>/dev/null || open "http://localhost:$PORT"
  elif command -v xdg-open >/dev/null; then xdg-open "http://localhost:$PORT"
  fi
}

if command -v python3 >/dev/null; then
  open_browser & python3 -m http.server $PORT
elif command -v npx >/dev/null; then
  open_browser & npx --yes http-server -p $PORT -c-1 .
else
  echo "  Не найден Python 3. Установите его с https://www.python.org/downloads/"
  read -r -p "  Нажмите Enter для выхода"
fi
