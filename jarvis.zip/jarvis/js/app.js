// Главная логика: связывает интерфейс, голос и мозг
(() => {
  const $ = (id) => document.getElementById(id);
  let S = Store.getSettings();
  let busy = false;

  // ---------- Утилиты интерфейса ----------
  const STATE_LABELS = {
    idle: () => (S.wakeOn ? `Скажите «${cap(firstWake())}»` : "Нажмите на микрофон"),
    awake: () => `Слушаю, ${S.userName || "сэр"} 🐾`,
    listening: () => "Слушаю…",
    thinking: () => "Думаю…",
    speaking: () => "Отвечаю",
    error: () => "Что-то пошло не так",
  };
  const STATUS = { idle: "ожидание", awake: "активен", listening: "слушает", thinking: "думает", speaking: "говорит", error: "ошибка" };
  const cap = (w) => w.charAt(0).toUpperCase() + w.slice(1);

  function firstWake() { return (S.wakeWords.split(",")[0] || "джарвис").trim(); }

  function setState(s) {
    HUD.setState(s);
    $("stateLabel").textContent = STATE_LABELS[s]();
    $("statusText").innerHTML = `<span class="pill">${STATUS[s]}</span>`;
  }

  function log(text, isErr = false) {
    const li = document.createElement("li");
    const time = new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    li.textContent = `[${time}] ${text}`;
    if (isErr) li.className = "err";
    $("log").prepend(li);
    while ($("log").children.length > 60) $("log").lastChild.remove();
  }

  function addMsg(role, text, sources = []) {
    const div = document.createElement("div");
    div.className = `msg ${role}`;
    div.textContent = text;
    if (sources.length) {
      const src = document.createElement("span");
      src.className = "src";
      src.append("Источники: ");
      const seen = new Set();
      sources.filter(s => !seen.has(s.uri) && seen.add(s.uri)).slice(0, 4).forEach((s, i) => {
        const a = document.createElement("a");
        a.href = s.uri; a.target = "_blank"; a.rel = "noopener"; a.textContent = s.title;
        if (i) src.append(" · ");
        src.append(a);
      });
      div.append(src);
    }
    $("chat").append(div);
    $("chat").scrollTop = $("chat").scrollHeight;
    return div;
  }

  function addLink(url) {
    const div = addMsg("sys", "Браузер заблокировал вкладку. Откройте вручную: ");
    const a = document.createElement("a");
    a.href = url; a.target = "_blank"; a.rel = "noopener"; a.textContent = url;
    div.append(a);
  }

  function renderHistory() {
    $("chat").innerHTML = "";
    for (const h of Store.getHistory().slice(-20)) addMsg(h.role === "user" ? "user" : "bot", h.text);
  }

  function refreshStatus() {
    $("brainText").textContent = S.apiKey ? S.model : "нет ключа";
    const v = Voice.pickVoice();
    $("voiceText").textContent = S.muted ? "выключен" : (v ? v.name : "системный");
    $("voiceText").title = v ? v.name : "";
    $("wakeText").textContent = S.wakeOn ? firstWake() : "выкл";
    $("searchText").textContent = S.useSearch ? "вкл" : "выкл";
    $("muteBtn").textContent = S.muted ? "🔇" : "🔊";
  }

  // Короткий сигнал при активации
  let audioCtx;
  function beep(freq = 880, dur = 0.12) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      const o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.type = "sine"; o.frequency.value = freq;
      g.gain.setValueAtTime(0.15, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + dur);
      o.connect(g).connect(audioCtx.destination);
      o.start(); o.stop(audioCtx.currentTime + dur);
    } catch (e) {}
  }

  async function say(text) {
    Voice.pause();
    await Voice.speak(text);
    Voice.resume();
  }

  // ---------- Инструменты, которые вызывает Джарвис ----------
  async function runTool(name, args) {
    log(`Инструмент: ${name}`);
    if (name === "open_url") {
      let url = String(args.url || "").trim();
      if (!/^https?:\/\//i.test(url)) url = "https://" + url;
      const w = window.open(url, "_blank", "noopener");
      if (!w) { addLink(url); return { ok: false, note: "Вкладка заблокирована браузером, ссылка показана на экране" }; }
      return { ok: true };
    }
    if (name === "set_timer") {
      const sec = Math.max(1, Number(args.seconds) || 60);
      const label = String(args.label || "Время вышло");
      setTimeout(() => {
        beep(660, 0.25); setTimeout(() => beep(880, 0.25), 300);
        addMsg("sys", `⏰ ${label}`);
        log(`Таймер: ${label}`);
        if ("Notification" in window && Notification.permission === "granted") new Notification("Джарвис", { body: label });
        say(`${S.userName || "сэр"}, напоминаю: ${label}`);
      }, sec * 1000);
      if ("Notification" in window && Notification.permission === "default") Notification.requestPermission();
      return { ok: true, fires_in_seconds: sec };
    }
    if (name === "remember") {
      Store.addMemory(String(args.fact || "").trim());
      return { ok: true };
    }
    return { ok: false, error: "Неизвестный инструмент" };
  }

  // ---------- Обработка команды ----------
  const STOP_WORDS = /^(стоп|хватит|замолчи|тихо|stop)[.!]?$/i;

  async function handleCommand(text) {
    text = text.trim();
    if (!text) return;
    if (STOP_WORDS.test(text)) { Voice.stopSpeaking(); setState("idle"); return; }
    if (busy) { log("Занят, команда пропущена"); return; }
    if (!S.apiKey) {
      addMsg("sys", "Сначала добавьте бесплатный ключ Gemini в настройках ⚙");
      openSettings();
      return;
    }

    busy = true;
    addMsg("user", text);
    $("interim").textContent = "";
    setState("thinking");
    Voice.pause();
    log("Запрос отправлен");

    try {
      const { text: answer, sources } = await Brain.ask(text, S, { runTool });
      addMsg("bot", answer, sources);
      log("Ответ получен");
      await Voice.speak(answer);
      setState("idle");
    } catch (e) {
      setState("error");
      addMsg("sys", e.message);
      log(e.message, true);
      await Voice.speak(e.message);
      setTimeout(() => setState("idle"), 1500);
    } finally {
      busy = false;
      Voice.resume();
    }
  }

  // ---------- Колбэки голоса ----------
  Voice.onCommand = (t) => {
    if (!S.wakeOn) Voice.stopListening(); // в режиме кнопки слушаем только одну фразу
    handleCommand(t);
  };
  Voice.onWake = () => { beep(); setState("awake"); log("Активирован"); setTimeout(() => { if (!busy && !Voice.isSpeaking) setState("idle"); }, 8000); };
  Voice.onInterim = (t) => { if (!busy) $("interim").textContent = t; };
  let lastErr = "", lastErrAt = 0;
  Voice.onError = (err) => {
    if (err === lastErr && Date.now() - lastErrAt < 15000) return; // не спамим одинаковыми ошибками
    lastErr = err; lastErrAt = Date.now();
    const map = {
      "not-allowed": "Нет доступа к микрофону. Разрешите его в адресной строке браузера.",
      "service-not-allowed": "Браузер не разрешает распознавание речи. Откройте в Chrome по адресу localhost.",
      "network": "Распознаванию речи нужен интернет.",
      "audio-capture": "Микрофон не найден.",
    };
    log(map[err] || `Ошибка распознавания: ${err}`, true);
    if (map[err]) addMsg("sys", map[err]);
  };
  Voice.onSpeakStart = () => setState("speaking");
  Voice.onSpeakEnd = () => { if (!busy) setState("idle"); };
  Voice.onPushToTalk = (on) => {
    $("micBtn").classList.toggle("active", on);
    if (on) setState("listening");
    else if (!busy) setState("idle");
  };
  Voice.onVoicesChanged = () => { refreshStatus(); if (!$("settings").classList.contains("hidden")) fillVoices(); };

  // ---------- Настройки ----------
  function fillVoices() {
    const sel = $("voice");
    const all = $("allVoices").checked;
    const list = Voice.listVoices(all, $("lang").value);
    sel.innerHTML = "";
    const auto = new Option("Автовыбор (лучший доступный)", "");
    sel.append(auto);
    for (const v of list) sel.append(new Option(`${v.name} — ${v.lang}${v.localService ? "" : " ☁"}`, v.voiceURI));
    sel.value = list.some(v => v.voiceURI === S.voiceURI) ? S.voiceURI : "";
    if (!list.length) sel.append(new Option("Голоса не найдены — отметьте «на всех языках»", "", false, false));
  }

  function fillModels(models) {
    const sel = $("model");
    const current = S.model;
    sel.innerHTML = "";
    const set = new Set(models && models.length ? models : ["gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-flash-latest"]);
    set.add(current);
    for (const m of set) sel.append(new Option(m, m));
    sel.value = current;
  }

  function renderMemory() {
    const box = $("memoryList");
    const mem = Store.getMemory();
    box.innerHTML = "";
    if (!mem.length) { box.textContent = "Пока ничего. Скажите: «Джарвис, запомни, что…»"; return; }
    mem.forEach((m, i) => {
      const row = document.createElement("div");
      const span = document.createElement("span"); span.textContent = m;
      const del = document.createElement("button"); del.textContent = "✕"; del.title = "Удалить";
      del.onclick = () => { Store.removeMemory(i); renderMemory(); };
      row.append(span, del);
      box.append(row);
    });
  }

  function syncRangeLabels() {
    $("rateVal").textContent = Number($("rate").value).toFixed(2);
    $("pitchVal").textContent = Number($("pitch").value).toFixed(2);
    $("volumeVal").textContent = Math.round($("volume").value * 100) + "%";
  }

  function openSettings() {
    $("apiKey").value = S.apiKey;
    fillModels();
    $("useSearch").checked = S.useSearch;
    $("allVoices").checked = S.allVoices;
    $("lang").value = S.lang;
    fillVoices();
    $("rate").value = S.rate; $("pitch").value = S.pitch; $("volume").value = S.volume;
    syncRangeLabels();
    $("wakeOn").checked = S.wakeOn;
    $("wakeWords").value = S.wakeWords;
    $("userName").value = S.userName;
    $("persona").value = S.persona;
    renderMemory();
    $("settings").classList.remove("hidden");
  }

  function readForm() {
    return {
      ...S,
      apiKey: $("apiKey").value.trim(),
      model: $("model").value || S.model,
      useSearch: $("useSearch").checked,
      voiceURI: $("voice").value,
      allVoices: $("allVoices").checked,
      rate: Number($("rate").value), pitch: Number($("pitch").value), volume: Number($("volume").value),
      wakeOn: $("wakeOn").checked,
      wakeWords: $("wakeWords").value.trim() || "джарвис, jarvis",
      lang: $("lang").value,
      userName: $("userName").value.trim() || "сэр",
      persona: $("persona").value.trim(),
    };
  }

  function saveSettings() {
    const wasWake = S.wakeOn;
    S = readForm();
    Store.saveSettings(S);
    Voice.applySettings(S);
    if (S.wakeOn && !wasWake) Voice.startListening();
    if (!S.wakeOn && wasWake) Voice.stopListening();
    refreshStatus();
    setState("idle");
    $("settings").classList.add("hidden");
    log("Настройки сохранены");
  }

  $("settingsBtn").onclick = openSettings;
  $("closeSettings").onclick = () => $("settings").classList.add("hidden");
  $("saveSettings").onclick = saveSettings;
  $("allVoices").onchange = fillVoices;
  $("lang").onchange = fillVoices;
  ["rate", "pitch", "volume"].forEach(id => $(id).oninput = syncRangeLabels);
  $("testVoice").onclick = () => {
    const tmp = readForm();
    Voice.applySettings(tmp);
    Voice.speak(`Добрый день, ${tmp.userName}. Я Джарвис. Так звучит мой голос.`, { force: true })
      .then(() => Voice.applySettings(S));
  };
  $("refreshModels").onclick = async () => {
    const key = $("apiKey").value.trim();
    if (!key) { alertInModal("Сначала вставьте ключ"); return; }
    $("refreshModels").textContent = "Загрузка…";
    try {
      const models = await Brain.listModels(key);
      S.model = $("model").value || S.model;
      fillModels(models);
      $("refreshModels").textContent = `Найдено: ${models.length}`;
    } catch (e) {
      $("refreshModels").textContent = "Ошибка";
      alertInModal(e.message);
    }
    setTimeout(() => ($("refreshModels").textContent = "Обновить список"), 2500);
  };
  $("clearMemory").onclick = () => { Store.clearMemory(); renderMemory(); };

  function alertInModal(text) {
    const h = document.createElement("div");
    h.className = "hint"; h.style.color = "var(--red)"; h.textContent = text;
    $("model").closest("label").after(h);
    setTimeout(() => h.remove(), 5000);
  }

  // ---------- Прочие кнопки ----------
  $("muteBtn").onclick = () => {
    S.muted = !S.muted;
    if (S.muted) Voice.stopSpeaking();
    Store.saveSettings(S); Voice.applySettings(S); refreshStatus();
  };
  $("clearBtn").onclick = () => { Store.clearHistory(); renderHistory(); log("Диалог очищен"); };
  $("micBtn").onclick = () => {
    if (Voice.isSpeaking) { Voice.stopSpeaking(); Voice.resume(); return; }
    if (!Voice.supported.recognition) { addMsg("sys", "Этот браузер не умеет распознавать речь. Откройте Джарвиса в Google Chrome."); return; }
    beep(); Voice.setPushToTalk(!Voice.isPushToTalk);
  };
  $("textForm").onsubmit = (e) => {
    e.preventDefault();
    const t = $("textInput").value;
    $("textInput").value = "";
    handleCommand(t);
  };
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") $("settings").classList.add("hidden");
  });

  // ---------- Часы ----------
  function tickClock() {
    const d = new Date();
    $("clock").textContent = d.toLocaleTimeString("ru-RU");
    $("date").textContent = d.toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" });
  }
  setInterval(tickClock, 1000); tickClock();

  function greeting() {
    const h = new Date().getHours();
    const part = h < 5 ? "Доброй ночи" : h < 12 ? "Доброе утро" : h < 18 ? "Добрый день" : "Добрый вечер";
    return `${part}, ${S.userName || "сэр"}. Все системы в норме.`;
  }

  // ---------- Запуск ----------
  $("initBtn").onclick = async () => {
    $("boot").classList.add("hidden");
    $("hud").classList.remove("hidden");
    requestAnimationFrame(HUD.resize);
    Voice.applySettings(S);
    refreshStatus();
    renderHistory();
    setState("idle");
    log("Системы запущены");

    if (!Voice.supported.recognition) {
      addMsg("sys", "Распознавание речи недоступно в этом браузере — откройте в Google Chrome или Edge. Пока можно писать текстом.");
    }
    const micOk = await Voice.initMicLevel((v) => HUD.setLevel(v));
    log(micOk ? "Микрофон подключён" : "Микрофон недоступен", !micOk);

    if (S.wakeOn && Voice.supported.recognition) Voice.startListening();

    if (!S.apiKey) {
      addMsg("bot", `${greeting()} Чтобы я мог думать, добавьте бесплатный ключ Gemini в настройках.`);
      await say(`${greeting()} Чтобы я мог думать, добавьте ключ Gemini в настройках.`);
      openSettings();
    } else {
      await say(greeting());
    }
  };
})();
