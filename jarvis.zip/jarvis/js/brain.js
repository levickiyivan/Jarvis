// «Мозг» Джарвиса — Gemini API (бесплатный ключ из Google AI Studio)
const Brain = (() => {
  const API = "https://generativelanguage.googleapis.com/v1beta";
  let searchWithFunctionsOk = true; // некоторые модели не дают совмещать поиск и функции

  // Инструменты, которые Джарвис может вызывать сам
  const functionDeclarations = [
    {
      name: "open_url",
      description: "Открыть сайт или поиск в новой вкладке браузера. Для YouTube, карт, почты и т.п. — подставь полный адрес.",
      parameters: {
        type: "object",
        properties: { url: { type: "string", description: "Полный адрес, начиная с https://" } },
        required: ["url"],
      },
    },
    {
      name: "set_timer",
      description: "Поставить таймер или напоминание через указанное количество секунд (пока открыта вкладка).",
      parameters: {
        type: "object",
        properties: {
          seconds: { type: "number", description: "Через сколько секунд сработать" },
          label: { type: "string", description: "О чём напомнить" },
        },
        required: ["seconds", "label"],
      },
    },
    {
      name: "remember",
      description: "Запомнить важный факт о пользователе надолго (имя, предпочтения, проекты), когда он просит запомнить или явно сообщает о себе что-то устойчивое.",
      parameters: {
        type: "object",
        properties: { fact: { type: "string", description: "Факт одной короткой фразой" } },
        required: ["fact"],
      },
    },
  ];

  function systemPrompt(s) {
    const now = new Date();
    const memory = Store.getMemory();
    return [
      `Ты — J.A.R.V.I.S. (Джарвис), личный ИИ-ассистент в духе дворецкого Тони Старка: вежливый, остроумный, сдержанно-ироничный, очень компетентный.`,
      `Обращайся к пользователю «${s.userName || "сэр"}».`,
      `Твои ответы зачитываются вслух, поэтому: говори коротко и по делу (обычно 1–3 предложения), без markdown, списков, эмодзи и таблиц, если пользователь сам не попросил подробностей. Числа и даты пиши так, чтобы их было удобно произнести.`,
      `Отвечай на языке пользователя (по умолчанию — русский).`,
      `Сейчас: ${now.toLocaleString("ru-RU", { dateStyle: "full", timeStyle: "short" })}, часовой пояс ${Intl.DateTimeFormat().resolvedOptions().timeZone}.`,
      `Если нужно открыть сайт — вызывай open_url. Таймеры и напоминания — set_timer. Если пользователь просит что-то запомнить — remember.`,
      memory.length ? `Что ты знаешь о пользователе:\n- ${memory.join("\n- ")}` : "",
      s.persona ? `Дополнительные указания пользователя: ${s.persona}` : "",
    ].filter(Boolean).join("\n\n");
  }

  function buildTools(s) {
    const tools = [{ functionDeclarations }];
    if (s.useSearch && searchWithFunctionsOk) tools.push({ googleSearch: {} });
    return tools;
  }

  async function call(s, contents, tools) {
    const res = await fetch(`${API}/models/${encodeURIComponent(s.model)}:generateContent`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": s.apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemPrompt(s) }] },
        contents,
        tools,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = data.error?.message || `HTTP ${res.status}`;
      const err = new Error(msg);
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function humanError(e) {
    const m = (e.message || "").toLowerCase();
    if (e.status === 400 && m.includes("api key")) return "Ключ Gemini не подошёл. Проверьте его в настройках.";
    if (e.status === 403) return "Доступ к Gemini запрещён. Возможно, ключ неверный или API не включён.";
    if (e.status === 404) return "Такой модели нет. Нажмите «Обновить список» в настройках и выберите другую.";
    if (e.status === 429) return "Лимит бесплатных запросов исчерпан. Подождите минуту или выберите модель полегче.";
    if (e.status >= 500) return "Серверы Gemini сейчас перегружены. Попробуйте ещё раз.";
    if (m.includes("failed to fetch")) return "Нет связи с сервером Gemini. Проверьте интернет.";
    return "Ошибка Gemini: " + e.message;
  }

  /**
   * Задать вопрос Джарвису.
   * @param {string} text — запрос пользователя
   * @param {object} s — настройки
   * @param {object} handlers — { runTool(name, args) => result }
   * @returns {Promise<{text: string, sources: Array}>}
   */
  async function ask(text, s, handlers) {
    if (!s.apiKey) throw new Error("NO_KEY");

    const history = Store.getHistory();
    const contents = history.map(h => ({ role: h.role, parts: [{ text: h.text }] }));
    contents.push({ role: "user", parts: [{ text }] });

    let sources = [];
    for (let round = 0; round < 5; round++) {
      let data;
      try {
        data = await call(s, contents, buildTools(s));
      } catch (e) {
        // модель не умеет поиск вместе с функциями — повторяем без поиска
        if (e.status === 400 && s.useSearch && searchWithFunctionsOk) {
          searchWithFunctionsOk = false;
          data = await call(s, contents, buildTools(s)).catch(err => { throw new Error(humanError(err)); });
        } else {
          throw new Error(humanError(e));
        }
      }

      const cand = data.candidates?.[0];
      if (!cand) {
        const reason = data.promptFeedback?.blockReason;
        throw new Error(reason ? "Запрос заблокирован фильтром Gemini." : "Gemini вернул пустой ответ.");
      }

      const chunks = cand.groundingMetadata?.groundingChunks || [];
      for (const c of chunks) if (c.web?.uri) sources.push({ uri: c.web.uri, title: c.web.title || c.web.uri });

      const parts = cand.content?.parts || [];
      const calls = parts.filter(p => p.functionCall);

      if (!calls.length) {
        const answer = parts.filter(p => p.text && !p.thought).map(p => p.text).join("").trim();
        const finalText = answer || "Прошу прощения, мне нечего ответить.";
        history.push({ role: "user", text }, { role: "model", text: finalText });
        Store.saveHistory(history);
        return { text: finalText, sources };
      }

      // Возвращаем ход модели как есть (с подписями мыслей), затем результаты функций
      contents.push({ role: "model", parts });
      const responses = [];
      for (const p of calls) {
        const { name, args } = p.functionCall;
        let result;
        try { result = await handlers.runTool(name, args || {}); }
        catch (e) { result = { ok: false, error: String(e.message || e) }; }
        responses.push({ functionResponse: { name, response: result } });
      }
      contents.push({ role: "user", parts: responses });
    }
    throw new Error("Слишком много шагов, прервал выполнение.");
  }

  async function listModels(apiKey) {
    const res = await fetch(`${API}/models?pageSize=200`, { headers: { "x-goog-api-key": apiKey } });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(humanError({ status: res.status, message: data.error?.message || "" }));
    return (data.models || [])
      .filter(m => (m.supportedGenerationMethods || []).includes("generateContent"))
      .map(m => m.name.replace(/^models\//, ""))
      .filter(n => /^gemini/.test(n) && !/(tts|image|embedding|live|audio|robotics|banana|vision)/i.test(n))
      .sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
  }

  return { ask, listModels };
})();
