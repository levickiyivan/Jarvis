// Голографический интерфейс: фон с частицами и «реактор» в центре, реагирующий на состояние и звук
const HUD = (() => {
  const COLORS = {
    idle: [168, 85, 247],      // фиолетовый Woof
    awake: [252, 211, 77],     // золото
    listening: [99, 102, 241], // индиго
    thinking: [252, 211, 77],
    speaking: [192, 132, 252],
    error: [255, 92, 122],
  };

  let state = "idle";
  let level = 0;          // текущий уровень звука 0..1
  let targetLevel = 0;
  let color = [...COLORS.idle];
  let t = 0;

  const bg = document.getElementById("bg");
  const rc = document.getElementById("reactor");
  const bctx = bg.getContext("2d");
  const rctx = rc.getContext("2d");
  let particles = [];

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    bg.width = innerWidth * dpr; bg.height = innerHeight * dpr;
    bctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const r = rc.getBoundingClientRect();
    rc.width = Math.max(1, r.width * dpr); rc.height = Math.max(1, r.height * dpr);
    rctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    particles = Array.from({ length: Math.round(innerWidth * innerHeight / 14000) }, () => ({
      x: Math.random() * innerWidth, y: Math.random() * innerHeight,
      vx: (Math.random() - .5) * .15, vy: (Math.random() - .5) * .15, r: Math.random() * 1.4 + .3,
    }));
  }

  const rgba = (a) => `rgba(${color[0] | 0},${color[1] | 0},${color[2] | 0},${a})`;

  function drawBackground() {
    const w = innerWidth, h = innerHeight;
    bctx.clearRect(0, 0, w, h);
    // мягкие светящиеся пятна в фирменных цветах
    const blobs = [
      [w * (0.2 + 0.05 * Math.sin(t * 0.3)), h * 0.25, Math.max(w, h) * 0.45, "99,102,241", 0.16],
      [w * (0.8 + 0.05 * Math.cos(t * 0.25)), h * 0.7, Math.max(w, h) * 0.5, "168,85,247", 0.16],
      [w * 0.55, h * (0.9 + 0.04 * Math.sin(t * 0.4)), Math.max(w, h) * 0.35, "252,211,77", 0.06],
    ];
    for (const [x, y, r, c, a] of blobs) {
      const g = bctx.createRadialGradient(x, y, 0, x, y, r);
      g.addColorStop(0, `rgba(${c},${a})`); g.addColorStop(1, `rgba(${c},0)`);
      bctx.fillStyle = g; bctx.fillRect(0, 0, w, h);
    }
    // звёздная пыль и связи
    for (const p of particles) {
      p.x = (p.x + p.vx + w) % w; p.y = (p.y + p.vy + h) % h;
      bctx.fillStyle = "rgba(216,196,255,0.45)";
      bctx.beginPath(); bctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); bctx.fill();
    }
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const a = particles[i], b = particles[j];
        const d = Math.hypot(a.x - b.x, a.y - b.y);
        if (d < 110) {
          bctx.strokeStyle = `rgba(168,85,247,${0.1 * (1 - d / 110)})`;
          bctx.beginPath(); bctx.moveTo(a.x, a.y); bctx.lineTo(b.x, b.y); bctx.stroke();
        }
      }
    }
  }

  function ring(cx, cy, r, width, alpha, start = 0, end = Math.PI * 2) {
    rctx.strokeStyle = rgba(alpha); rctx.lineWidth = width;
    rctx.beginPath(); rctx.arc(cx, cy, r, start, end); rctx.stroke();
  }

  function drawReactor() {
    const w = rc.clientWidth, h = rc.clientHeight;
    const cx = w / 2, cy = h / 2, R = Math.min(w, h) / 2 * 0.92;
    rctx.clearRect(0, 0, w, h);

    // плавные значения
    const target = COLORS[state] || COLORS.idle;
    for (let i = 0; i < 3; i++) color[i] += (target[i] - color[i]) * 0.08;
    if (state === "speaking") targetLevel = 0.35 + 0.35 * Math.abs(Math.sin(t * 9)) * Math.random();
    else if (state === "thinking") targetLevel = 0.15 + 0.1 * Math.sin(t * 4);
    level += (targetLevel - level) * 0.25;

    rctx.shadowColor = rgba(1); rctx.shadowBlur = 18;

    // внешнее кольцо — фирменный градиент индиго → фиолет → золото
    const og = rctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
    og.addColorStop(0, "#6366f1"); og.addColorStop(0.5, "#a855f7"); og.addColorStop(1, "#fcd34d");
    rctx.strokeStyle = og; rctx.lineWidth = 2.5;
    rctx.beginPath(); rctx.arc(cx, cy, R, 0, Math.PI * 2); rctx.stroke();
    rctx.save(); rctx.translate(cx, cy); rctx.rotate(t * 0.15);
    for (let i = 0; i < 120; i++) {
      const a = (i / 120) * Math.PI * 2;
      const long = i % 10 === 0;
      rctx.strokeStyle = rgba(long ? 0.9 : 0.35); rctx.lineWidth = long ? 2 : 1;
      rctx.beginPath();
      rctx.moveTo(Math.cos(a) * (R - 4), Math.sin(a) * (R - 4));
      rctx.lineTo(Math.cos(a) * (R - (long ? 18 : 10)), Math.sin(a) * (R - (long ? 18 : 10)));
      rctx.stroke();
    }
    rctx.restore();

    // вращающиеся дуги
    const speed = state === "thinking" ? 2.4 : state === "idle" ? 0.4 : 1.1;
    for (let k = 0; k < 3; k++) {
      const rr = R * (0.82 - k * 0.1);
      const off = t * speed * (k % 2 ? -1 : 1) + k;
      for (let s = 0; s < 3; s++) {
        const a0 = off + s * (Math.PI * 2 / 3);
        ring(cx, cy, rr, 3 - k * 0.6, 0.75 - k * 0.15, a0, a0 + Math.PI / 2.6);
      }
    }

    // аудио-волна по кругу
    const waveR = R * 0.5;
    rctx.strokeStyle = rgba(0.9); rctx.lineWidth = 2;
    rctx.beginPath();
    const N = 180;
    for (let i = 0; i <= N; i++) {
      const a = (i / N) * Math.PI * 2;
      const n = Math.sin(a * 6 + t * 3) * 0.5 + Math.sin(a * 11 - t * 5) * 0.3 + Math.sin(a * 17 + t * 7) * 0.2;
      const rr = waveR + n * level * R * 0.16 + Math.sin(t * 2) * 2;
      const x = cx + Math.cos(a) * rr, y = cy + Math.sin(a) * rr;
      i ? rctx.lineTo(x, y) : rctx.moveTo(x, y);
    }
    rctx.closePath(); rctx.stroke();

    // треугольный сердечник
    rctx.save(); rctx.translate(cx, cy); rctx.rotate(-t * 0.3);
    const tri = R * 0.24;
    rctx.strokeStyle = rgba(0.8); rctx.lineWidth = 2;
    rctx.beginPath();
    for (let i = 0; i < 3; i++) {
      const a = i * Math.PI * 2 / 3 - Math.PI / 2;
      i ? rctx.lineTo(Math.cos(a) * tri, Math.sin(a) * tri) : rctx.moveTo(Math.cos(a) * tri, Math.sin(a) * tri);
    }
    rctx.closePath(); rctx.stroke();
    rctx.restore();

    // светящееся ядро
    const coreR = R * (0.14 + level * 0.08 + Math.sin(t * 2) * 0.006);
    const g = rctx.createRadialGradient(cx, cy, 0, cx, cy, coreR * 2.2);
    g.addColorStop(0, "rgba(255,255,255,0.95)");
    g.addColorStop(0.18, "rgba(252,211,77,0.9)");
    g.addColorStop(0.45, rgba(0.75));
    g.addColorStop(1, rgba(0));
    rctx.fillStyle = g; rctx.beginPath(); rctx.arc(cx, cy, coreR * 2.2, 0, Math.PI * 2); rctx.fill();
    rctx.shadowBlur = 0;
  }

  function loop() {
    t += 1 / 60;
    drawBackground();
    drawReactor();
    requestAnimationFrame(loop);
  }

  addEventListener("resize", resize);
  resize();
  requestAnimationFrame(loop);

  return {
    setState(s) { state = s; },
    setLevel(v) { if (state !== "speaking" && state !== "thinking") targetLevel = Math.min(1, v); },
    resize,
  };
})();
