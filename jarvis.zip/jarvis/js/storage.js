// Хранение настроек, истории диалога и долговременной памяти в браузере (localStorage)
const Store = (() => {
  const KEY_SETTINGS = "jarvis.settings";
  const KEY_HISTORY = "jarvis.history";
  const KEY_MEMORY = "jarvis.memory";

  const defaults = {
    apiKey: "",
    model: "gemini-3.6-flash",
    useSearch: true,
    voiceURI: "",
    allVoices: false,
    rate: 1.0,
    pitch: 0.9,
    volume: 1.0,
    muted: false,
    wakeOn: true,
    wakeWords: "джарвис, jarvis, джарвиз, жарвис",
    lang: "ru-RU",
    userName: "сэр",
    persona: "",
  };

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function write(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* хранилище недоступно */ }
  }

  return {
    getSettings() { return { ...defaults, ...read(KEY_SETTINGS, {}) }; },
    saveSettings(s) { write(KEY_SETTINGS, s); },

    // История: массив {role: "user"|"model", text}
    getHistory() { return read(KEY_HISTORY, []); },
    saveHistory(h) { write(KEY_HISTORY, h.slice(-40)); },
    clearHistory() { write(KEY_HISTORY, []); },

    // Память: массив строк-фактов
    getMemory() { return read(KEY_MEMORY, []); },
    addMemory(fact) {
      const m = read(KEY_MEMORY, []);
      if (!m.includes(fact)) m.push(fact);
      write(KEY_MEMORY, m.slice(-100));
    },
    removeMemory(i) {
      const m = read(KEY_MEMORY, []);
      m.splice(i, 1);
      write(KEY_MEMORY, m);
    },
    clearMemory() { write(KEY_MEMORY, []); },
  };
})();
