// Речь: синтез (встроенные голоса браузера/системы) и распознавание (Web Speech API)
const Voice = (() => {
  const synth = window.speechSynthesis;
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

  let settings = Store.getSettings();
  let voices = [];
  let speaking = false;

  // ---------- Синтез ----------
  function loadVoices() {
    voices = synth ? synth.getVoices() : [];
    return voices;
  }
  if (synth) synth.onvoiceschanged = () => { loadVoices(); Voice.onVoicesChanged && Voice.onVoicesChanged(); };

  function listVoices(all, lang) {
    const base = (lang || "ru-RU").slice(0, 2).toLowerCase();
    const list = loadVoices().filter(v => all || v.lang.toLowerCase().startsWith(base));
    // сначала качественные (Google / Microsoft Online / Natural)
    const score = v => (/natural|online|neural/i.test(v.name) ? 0 : /google/i.test(v.name) ? 1 : 2);
    return list.sort((a, b) => score(a) - score(b) || a.name.localeCompare(b.name));
  }

  function pickVoice() {
    const all = loadVoices();
    if (settings.voiceURI) {
      const v = all.find(v => v.voiceURI === settings.voiceURI);
      if (v) return v;
    }
    return listVoices(false, settings.lang)[0] || all[0] || null;
  }

  // Убираем разметку, чтобы Джарвис не читал звёздочки и ссылки
  function cleanForSpeech(text) {
    return text
      .replace(/```[\s\S]*?```/g, " код смотрите на экране. ")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .replace(/https?:\/\/\S+/g, "ссылка на экране")
      .replace(/[*_#>`~|]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  // Длинный текст режем на куски — Chrome иногда обрывает длинные фразы
  function chunk(text, max = 180) {
    const parts = text.match(/[^.!?…]+[.!?…]*/g) || [text];
    const out = [];
    let cur = "";
    for (const p of parts) {
      if ((cur + p).length > max && cur) { out.push(cur.trim()); cur = ""; }
      cur += p;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }

  function speak(text, { force = false } = {}) {
    return new Promise(resolve => {
      if (!synth || (settings.muted && !force)) return resolve();
      const clean = cleanForSpeech(text);
      if (!clean) return resolve();
      synth.cancel();
      const pieces = chunk(clean);
      const voice = pickVoice();
      speaking = true;
      Voice.onSpeakStart && Voice.onSpeakStart();
      let i = 0;
      const next = () => {
        if (i >= pieces.length) {
          speaking = false;
          Voice.onSpeakEnd && Voice.onSpeakEnd();
          return resolve();
        }
        const u = new SpeechSynthesisUtterance(pieces[i++]);
        if (voice) { u.voice = voice; u.lang = voice.lang; } else { u.lang = settings.lang; }
        u.rate = settings.rate; u.pitch = settings.pitch; u.volume = settings.volume;
        u.onend = next;
        u.onerror = next;
        synth.speak(u);
      };
      next();
    });
  }

  function stopSpeaking() {
    if (synth) synth.cancel();
    if (speaking) { speaking = false; Voice.onSpeakEnd && Voice.onSpeakEnd(); }
  }

  // ---------- Распознавание ----------
  let rec = null;
  let running = false;
  let paused = false;       // пауза, пока Джарвис говорит
  let awakeUntil = 0;       // после слова-активатора ждём команду несколько секунд
  let pushToTalk = false;   // режим кнопки микрофона
  let lastErrorAt = 0;

  function wakeList() {
    return settings.wakeWords.split(",").map(w => w.trim().toLowerCase()).filter(Boolean);
  }

  function handleFinal(text) {
    const raw = text.trim();
    if (!raw) return;
    const low = raw.toLowerCase();

    if (pushToTalk) {
      pushToTalk = false;
      Voice.onPushToTalk && Voice.onPushToTalk(false);
      Voice.onCommand && Voice.onCommand(raw);
      return;
    }
    if (Date.now() < awakeUntil) {
      awakeUntil = 0;
      Voice.onCommand && Voice.onCommand(raw);
      return;
    }
    if (!settings.wakeOn) return;

    for (const w of wakeList()) {
      const idx = low.indexOf(w);
      if (idx !== -1) {
        const cmd = raw.slice(idx + w.length).replace(/^[\s,.!?:;—-]+/, "").trim();
        if (cmd.length > 1) {
          Voice.onCommand && Voice.onCommand(cmd);
        } else {
          awakeUntil = Date.now() + 8000;
          Voice.onWake && Voice.onWake();
        }
        return;
      }
    }
  }

  function createRecognizer() {
    if (!SR) return null;
    const r = new SR();
    r.lang = settings.lang;
    r.continuous = true;
    r.interimResults = true;
    r.maxAlternatives = 1;

    r.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        if (res.isFinal) handleFinal(res[0].transcript);
        else interim += res[0].transcript;
      }
      Voice.onInterim && Voice.onInterim(interim);
    };
    r.onerror = (e) => {
      if (e.error === "no-speech" || e.error === "aborted") return;
      lastErrorAt = Date.now();
      Voice.onError && Voice.onError(e.error);
      if (e.error === "not-allowed" || e.error === "service-not-allowed") running = false;
    };
    r.onend = () => {
      Voice.onInterim && Voice.onInterim("");
      // Chrome сам останавливает распознавание через ~минуту — перезапускаем
      // после ошибки (например, нет сети) ждём подольше, чтобы не крутиться в цикле
      const delay = Date.now() - lastErrorAt < 2000 ? 3000 : 250;
      if (running && !paused) setTimeout(safeStart, delay);
    };
    return r;
  }

  function safeStart() {
    if (!rec || paused || !running) return;
    try { rec.start(); } catch (e) { /* уже запущено */ }
  }

  function startListening() {
    if (!SR) return false;
    if (!rec) rec = createRecognizer();
    running = true;
    safeStart();
    return true;
  }

  function stopListening() {
    running = false;
    if (rec) try { rec.abort(); } catch (e) {}
  }

  function pause() {
    paused = true;
    if (rec) try { rec.abort(); } catch (e) {}
  }

  function resume() {
    paused = false;
    if (running) setTimeout(safeStart, 300);
  }

  function setPushToTalk(on) {
    pushToTalk = on;
    if (on) {
      if (!running) startListening();
      else if (paused) resume();
    }
    Voice.onPushToTalk && Voice.onPushToTalk(on);
  }

  function applySettings(s) {
    const langChanged = settings.lang !== s.lang;
    settings = s;
    if (rec && langChanged) {
      stopListening();
      rec = createRecognizer();
      if (s.wakeOn) startListening();
    }
  }

  // ---------- Уровень микрофона для анимации ----------
  async function initMicLevel(onLevel) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const src = ctx.createMediaStreamSource(stream);
      const an = ctx.createAnalyser();
      an.fftSize = 512;
      src.connect(an);
      const buf = new Uint8Array(an.fftSize);
      const tick = () => {
        an.getByteTimeDomainData(buf);
        let sum = 0;
        for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
        onLevel(Math.min(1, Math.sqrt(sum / buf.length) * 4));
        requestAnimationFrame(tick);
      };
      tick();
      return true;
    } catch (e) {
      return false;
    }
  }

  return {
    supported: { synth: !!synth, recognition: !!SR },
    applySettings, listVoices, pickVoice, speak, stopSpeaking,
    startListening, stopListening, pause, resume, setPushToTalk, initMicLevel,
    get isSpeaking() { return speaking; },
    get isPushToTalk() { return pushToTalk; },
    // колбэки задаются в app.js
    onCommand: null, onWake: null, onInterim: null, onError: null,
    onSpeakStart: null, onSpeakEnd: null, onVoicesChanged: null, onPushToTalk: null,
  };
})();
