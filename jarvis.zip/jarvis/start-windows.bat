@echo off
chcp 65001 >nul
title J.A.R.V.I.S.
cd /d "%~dp0"
set PORT=8777
echo.
echo   J.A.R.V.I.S. запускается на http://localhost:%PORT%
echo   Не закрывайте это окно, пока пользуетесь Джарвисом.
echo.

where py >nul 2>nul && (
  start "" "http://localhost:%PORT%"
  py -m http.server %PORT%
  goto :eof
)
where python >nul 2>nul && (
  start "" "http://localhost:%PORT%"
  python -m http.server %PORT%
  goto :eof
)
where npx >nul 2>nul && (
  start "" "http://localhost:%PORT%"
  npx --yes http-server -p %PORT% -c-1 .
  goto :eof
)

echo   Не найден ни Python, ни Node.js.
echo   Установите Python с https://www.python.org/downloads/ (отметьте "Add to PATH")
echo   и запустите этот файл снова.
pause
